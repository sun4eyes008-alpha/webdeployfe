/**
 * FEEDBACK DATA FOR UBANK
 */

window.ubankFlowchartDataFeedback = {
  "1. GÓP Ý TÍCH CỰC (UBANK)": {
    "Về ứng dụng Ubank": {
      "displayName": "Góp ý về ứng dụng Ubank",
      "pdf": "",
      "note": "Ghi nhận góp ý tích cực về ứng dụng Ubank.",
      "xmttib": "1. Không cần XMTT"
    }
  },
  "2. GÓP Ý TIÊU CỰC (UBANK)": {
    "Về ứng dụng Ubank": {
      "displayName": "Góp ý về ứng dụng Ubank",
      "pdf": "",
      "note": "Ghi nhận góp ý tiêu cực về ứng dụng Ubank.",
      "xmttib": "1. Không cần XMTT"
    }
  }
};